//
//  Project2App.swift
//  Project2
//
//  Created by Thomas Johnson on 10/27/25.
//

import SwiftUI

@main
struct Project2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
